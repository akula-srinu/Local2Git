$Date = Get-Date
Write-Host "User Name : " ${env:UserName} 
Write-Host "Password : " ${env:PassWord} 
Write-Host "Duo Code : " ${env:DuoCode}
Write-Host "Noetix Package Version : " ${env:PkgVersion}

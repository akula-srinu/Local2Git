$Server = Read-Host -Prompt 'Input your server  name'
$User = Read-Host -Prompt 'Input the user name'
$Date = Get-Date
Write-Host "You input server '$Server' and '$User' on '$Date'"
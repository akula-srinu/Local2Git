$Date = Get-Date
Write-Host "You input server '${env:ServerName}' and '${env:UserName}' on '$Date'"
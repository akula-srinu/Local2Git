$Date = Get-Date
Write-Host "User Name : " ${env:VsatUserName} 
Write-Host "Password : " ${env:PassDuo} 
Write-Host "Noetix Package Version : " ${env:PkgVersion}
